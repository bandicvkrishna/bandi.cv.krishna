<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'uSRfkAwFDz9FeM5OfxqqNr9rj');
    define('CONSUMER_SECRET', 'WMR7tVlQwXhc9Tz43ePlMDSL53mAHijMa8cdqPHqMdXWhUDpet');

    // User Access Token
    define('ACCESS_TOKEN', '862319566793326593-mlQkQxa0Eiyoegdzx0eXTemUI8V5rdW');
    define('ACCESS_SECRET', 'ljHyvywCwxcil2wfqg5p6Pa7cZvHHcjfw2HLf5KGZJ986');
	
	// Cache Settings
	define('CACHE_ENABLED', false);
	define('CACHE_LIFETIME', 3600); // in seconds
	define('HASH_SALT', md5(dirname(__FILE__)));